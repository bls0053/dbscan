from sklearn.datasets import make_blobs
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import random
import math
from array import *
import seaborn as sns

from sklearn import cluster, datasets, mixture
from sklearn.neighbors import kneighbors_graph
from sklearn.preprocessing import StandardScaler




def dbscan(eps, minpts, df):

    # Univisited points
    unvisited = list(df.index)

    # Stack to handle neighbors
    stack = set()

    # Final cluster array
    clusters = [[]]

    # Current cluster count (Noise is of cluster '0')
    curr_c = 1
    
    b_list = []

    #Runs until no more points
    while (len(unvisited) != 0):

        first = True
        stack.add(random.choice(unvisited))
        #stack.add(2607)
        clus_elements = []
        

        while (len(stack) != 0):
            i = stack.pop()

            temp = []
            
            neighbors, core, border, noise = find_neigh(eps, minpts, df, i)


            # Handles border point edge case
            if border & first:
                unvisited.remove(i)
                b_list.append(i)
                continue

            unvisited.remove(i)

            if (len(b_list) != 0):
                temp = set(neighbors) & set(temp)
                for j in temp:
                    b_list.remove(j)

            neighbors = set(neighbors) & set(unvisited) | set(temp)

            if (core):
                stack.update(neighbors)
                clus_elements.append(i)
 
            elif (border):
                clus_elements.append(i)

            elif (noise):
                clusters[0].append(i)

            first = False

        if (len(clus_elements) > 0):
            #clusters.append(t)
            clusters.append([])
            clusters[curr_c].extend(clus_elements)
            curr_c += 1

    clusters[0].extend(b_list)
    return clusters     


def find_neigh(eps, minpts, df, i):

    x1,y1 = df.iloc[i]['X'], df.iloc[i]['Y']
    neigh = []

    for j in range (0,len(df)):

        if (j == i):

            continue
        
        x2,y2 = df.iloc[j]['X'], df.iloc[j]['Y']

        dist = math.sqrt( ((x2-x1)**2) + ((y2-y1)**2) )
         
        if dist <= eps:
            neigh.append(j)
    

    if (len(neigh) == 0):
        return (neigh, False, False, True)
    
    elif (len(neigh) < minpts and len(neigh) > 0):
        return (neigh, False, True, False)

    elif (len(neigh) >= minpts):
        return (neigh, True, False, False)



n_samples = 500
seed = 30

eps = .25
minpts = 7

data = []


X,y = datasets.make_blobs(n_samples=n_samples, random_state=seed)
data.append(X)

X,y = datasets.make_circles(
    n_samples=n_samples, factor=0.5, noise=0.05, random_state=seed)
data.append(X)

X,y = datasets.make_moons(n_samples=n_samples, noise=0.05, random_state=seed)
data.append(X)

rng = np.random.RandomState(seed)
X,y = rng.rand(n_samples, 2), None
data.append(X)



fig, axes = plt.subplots(2, 4, figsize=(12, 6))

titles = ["Noisy Circles", "Noisy Moons", "Blobs", "Random", 
          "Noisy Circles DBSCAN", "Noisy Moons DBSCAN", "Blobs DBSCAN", "Random DBSCAN"]

for i, ax in enumerate(axes.ravel()):
    ax.set_title(titles[i])




for i in range (0,len(data)):

    df = pd.DataFrame(data[i], columns = ["X", "Y"] )

    ax = axes[0,i]
    ax.scatter(df['X'], df['Y'], label='', color='blue')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')

    clusters_array = dbscan(eps,minpts,df)

    if i == 0:
        print(clusters_array)

    num_colors = 50
    distinct_colors = sns.color_palette("hsv", n_colors=num_colors).as_hex()

    ax = axes[1, i]

    for j, indices in enumerate(clusters_array):

        x_points = [df.loc[idx, 'X'] for idx in indices]
        y_points = [df.loc[idx, 'Y'] for idx in indices]
        
        if (j != 0):
            color = random.choice(distinct_colors)
            distinct_colors.remove(color)

            ax.scatter(x_points, y_points, label=f'cluster {i}', color=color)

        else:
            color = '000000'

            ax.scatter(x_points, y_points, label='Noise', color=color)



plt.show()